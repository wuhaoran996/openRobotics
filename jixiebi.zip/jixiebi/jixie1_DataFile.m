% Simscape(TM) Multibody(TM) version: 4.8

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(13).translation = [0.0 0.0 0.0];
smiData.RigidTransform(13).angle = 0.0;
smiData.RigidTransform(13).axis = [0.0 0.0 0.0];
smiData.RigidTransform(13).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0 384.99999999999994 0];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[����-1:-:1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [-7.720024269780097e-14 50.000000000000014 1.6783742351121363e-13];  % mm
smiData.RigidTransform(2).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(2).axis = [0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(2).ID = 'F[����-1:-:1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [-123.74368670764579 514.25442435894081 -344.71999940354169];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(3).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(3).ID = 'B[1-1:-:2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-5.076584799323116e-13 -4.029169081853766e-14 4.8831988433859665e-14];  % mm
smiData.RigidTransform(4).angle = 2.0943951023931948;  % rad
smiData.RigidTransform(4).axis = [-0.5773502691896254 -0.57735026918962529 -0.57735026918962662];
smiData.RigidTransform(4).ID = 'F[1-1:-:2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [1200 109.99999999999999 -1.1102230246251565e-13];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = 'B[2-1:-:3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [3.5051626739036369e-13 3.3414627206545381e-13 -9.2956111483133622e-13];  % mm
smiData.RigidTransform(6).angle = 2.6443013074044545e-15;  % rad
smiData.RigidTransform(6).axis = [-0.34198931084597178 -0.93970384231793858 4.2489779637108035e-16];
smiData.RigidTransform(6).ID = 'F[2-1:-:3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [235.62177826491103 0 59.999999999999829];  % mm
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(7).ID = 'B[3-1:-:4-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [5.6843418860808015e-13 15.000000000000075 -2.1653789872289053e-12];  % mm
smiData.RigidTransform(8).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(8).axis = [0.57735026918962595 -0.57735026918962584 0.5773502691896254];
smiData.RigidTransform(8).ID = 'F[3-1:-:4-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [-50.000000000000043 745.00000000000034 0];  % mm
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(9).ID = 'B[4-1:-:5-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [2.1316282072803006e-13 99.999999999999801 8.9528384705772623e-13];  % mm
smiData.RigidTransform(10).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(10).axis = [0.57735026918962595 -0.57735026918962573 0.57735026918962562];
smiData.RigidTransform(10).ID = 'F[4-1:-:5-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [126.99999999999977 49.999999999999822 -1.1102230246251565e-13];  % mm
smiData.RigidTransform(11).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(11).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(11).ID = 'B[5-1:-:6-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-1.9626678272260342e-13 1.1534341923339073e-13 8.7167835564189736e-15];  % mm
smiData.RigidTransform(12).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(12).axis = [-0.57735026918962606 -0.57735026918962518 -0.57735026918962595];
smiData.RigidTransform(12).ID = 'F[5-1:-:6-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [-32.075362528077299 -251.51866705165648 800];  % mm
smiData.RigidTransform(13).angle = 0;  % rad
smiData.RigidTransform(13).axis = [0 0 0];
smiData.RigidTransform(13).ID = 'RootGround[����-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(7).mass = 0.0;
smiData.Solid(7).CoM = [0.0 0.0 0.0];
smiData.Solid(7).MoI = [0.0 0.0 0.0];
smiData.Solid(7).PoI = [0.0 0.0 0.0];
smiData.Solid(7).color = [0.0 0.0 0.0];
smiData.Solid(7).opacity = 0.0;
smiData.Solid(7).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 56.699869327575989;  % kg
smiData.Solid(1).CoM = [0 190.48973749065294 0];  % mm
smiData.Solid(1).MoI = [2848183.7188985422 3978640.4096453907 2848183.7189436052];  % kg*mm^2
smiData.Solid(1).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(1).color = [1 1 1];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = '����*:*Ĭ��';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 4.1224071960421229;  % kg
smiData.Solid(2).CoM = [2.3134622828927415e-05 393.54021613961316 0.00027878536754641429];  % mm
smiData.Solid(2).MoI = [223337.39718671588 3801.9509289885264 223493.86343616742];  % kg*mm^2
smiData.Solid(2).PoI = [0.015617034447519634 -0.017299900335357509 0.001297742753455438];  % kg*mm^2
smiData.Solid(2).color = [1 1 1];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = '4*:*Ĭ��';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 74.265673303528374;  % kg
smiData.Solid(3).CoM = [3.76630023647804 207.14036712507036 -123.94047659543837];  % mm
smiData.Solid(3).MoI = [3854468.4351378507 3590868.6209095321 2724673.2390787345];  % kg*mm^2
smiData.Solid(3).PoI = [1258188.9643331391 61758.183962214869 -85651.157522530077];  % kg*mm^2
smiData.Solid(3).color = [1 1 1];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = '1*:*Ĭ��';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 22.779984093040902;  % kg
smiData.Solid(4).CoM = [508.47702150191589 50.195609662872251 -3.7146191693708528e-08];  % mm
smiData.Solid(4).MoI = [79769.005869794215 3353513.3581569726 3329688.222073541];  % kg*mm^2
smiData.Solid(4).PoI = [7.5331988139488637e-05 -0.00011450759653032558 2271.8459569631609];  % kg*mm^2
smiData.Solid(4).color = [1 1 1];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = '2*:*Ĭ��';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 1.7133185005737221;  % kg
smiData.Solid(5).CoM = [78.461578710497108 0 60.000000000000007];  % mm
smiData.Solid(5).MoI = [4701.5353764789752 16670.096407597375 14200.642803302966];  % kg*mm^2
smiData.Solid(5).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(5).color = [1 1 1];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = '3*:*Ĭ��';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.30264998342060556;  % kg
smiData.Solid(6).CoM = [44.16875800757915 50 0];  % mm
smiData.Solid(6).MoI = [520.23522033787526 1039.9701018427197 1290.4820168311473];  % kg*mm^2
smiData.Solid(6).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(6).color = [1 1 1];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = '5*:*Ĭ��';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 0.95053975605103835;  % kg
smiData.Solid(7).CoM = [0 -50.612041081859232 0];  % mm
smiData.Solid(7).MoI = [1784.3541877371404 9434.5373920599923 10186.401272792866];  % kg*mm^2
smiData.Solid(7).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(7).color = [1 1 1];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = '6*:*Ĭ��';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(6).Rz.Pos = 0.0;
smiData.RevoluteJoint(6).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = -114.70102928363076;  % deg
smiData.RevoluteJoint(1).ID = '[����-1:-:1-1]';

smiData.RevoluteJoint(2).Rz.Pos = -31.970821016359569;  % deg
smiData.RevoluteJoint(2).ID = '[1-1:-:2-1]';

smiData.RevoluteJoint(3).Rz.Pos = -137.59799141235163;  % deg
smiData.RevoluteJoint(3).ID = '[2-1:-:3-1]';

smiData.RevoluteJoint(4).Rz.Pos = -135.93113469397821;  % deg
smiData.RevoluteJoint(4).ID = '[3-1:-:4-1]';

smiData.RevoluteJoint(5).Rz.Pos = 46.547547339813342;  % deg
smiData.RevoluteJoint(5).ID = '[4-1:-:5-1]';

smiData.RevoluteJoint(6).Rz.Pos = -146.6659460352767;  % deg
smiData.RevoluteJoint(6).ID = '[5-1:-:6-1]';

