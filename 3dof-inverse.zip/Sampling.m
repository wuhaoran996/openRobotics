
function P = Sampling(P0,P1)
v=1;
% Viet phuong trinh tham so cua duong thang qu 2 diem lay mau
 a=P1(1)-P0(1);
 b=P1(2)-P0(2);
 c=sqrt((a)^2+(b)^2);
 NumOfSampling=round(c);% So diem can lay mau
 t=linspace(P0(1),P1(1),NumOfSampling);
 k=linspace(0,1,NumOfSampling);
 X=t;
 Y=b*k+P0(2);
 P=zeros(length(t),2);
 P(:,1)=X';
 P(:,2)=Y';
end