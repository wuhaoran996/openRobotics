clear all;
clc;
%����˳�
l1=70;
l2=80;
l3=66;
v=0.0005;
dt=1;
%��ʼλ��
x0=0; y0=100; z0=10;
P0=[x0 y0];
x = x0;
y = y0;
z = z0;
theta01=atan2(-x,y);
a=-sin(theta01)*x+cos(theta01)*y;
b=z - l1;
c3=(a^2+b^2-l3^2-l2^2)/(2*l2*l3);
s3=-sqrt(1-c3^2);
a1=l3*c3+l2;
b1=l3*s3;
c2=(b*b1+a*a1)/(a1^2+b1^2);
s2=(c2*a1-a)/b1;
theta02=atan2(s2,c2);
theta03=atan2(s3,c3);
%%����ƽ��켣
QD=[Sampling([x0 y0],[x0 y0+5]);Sampling([x0-5 y0+5],[x0-5 y0+10]);
    Sampling([x0-5 y0+10],[x0 y0+10]);Sampling([x0 y0+10],[x0-5 y0+10]);
    Sampling([x0-5 y0+10],[x0-5 y0+5]);Sampling([x0-5 y0+5],[x0 y0+5]);
    Sampling([x0 y0+5],[x0 y0]);Sampling([x0 y0],[x0-10 y0]);
     Sampling([x0-10 y0],[x0-10 y0+10]);Sampling([x0-10 y0+10],[x0-15 y0+10]);
    Sampling([x0-15 y0+10],[x0-10 y0+10]);Sampling([x0-10 y0+10],[x0-10 y0+5]);
     Sampling([x0-10 y0+5],[x0-15 y0+5]);Sampling([x0-15 y0+5],[x0-15 y0]);
    Sampling([x0-15 y0],[x0-10 y0]);Sampling([x0-10 y0],[x0-20 y0]);
    Sampling([x0-20 y0],[x0-20 y0+10]);Sampling([x0-20 y0+10],[x0-25 y0+10]);
   Sampling([x0-25 y0+10],[x0-25 y0+5]);Sampling([x0-25 y0+5],[x0-20 y0+5]);
    Sampling([x0-20 y0+5],[x0-20 y0]);Sampling([x0-20 y0],[x0-25 y0]);
    Sampling([x0-25 y0],[x0-25 y0+5]);Sampling([x0-25 y0+5],[x0-25 y0]);
     Sampling([x0-25 y0],[x0-30 y0]);Sampling([x0-30 y0],[x0-30 y0+10]);
    Sampling([x0-30 y0+10],[x0-30 y0]);Sampling([x0-30 y0],[x0-40 y0]);
    Sampling([x0-40 y0],[x0-40 y0+10]);Sampling([x0-40 y0+10],[x0-35 y0+10]);];
Toado0 = [P0;QD];
% Toado0 = Fillter(Toado0);
theta0(1,1)=0;            theta0(1,2)=theta01*180/pi;
theta0(1,3)=theta02*180/pi;      theta0(1,4)=theta03*180/pi;
%��֪�켣���˶�ѧ����
for i=2:length(Toado0(:,1))
    x = Toado0(i,1);
    y = Toado0(i,2);
    theta01=atan2(-x,y);
    a=-sin(theta01)*x+cos(theta01)*y;
    b=z - l1;
    c3=(a^2+b^2-l3^2-l2^2)/(2*l2*l3);
    s3=-sqrt(1-c3^2);
    a1=l3*c3+l2;
    b1=l3*s3;
    c2=(b*b1+a*a1)/(a1^2+b1^2);
    s2=(c2*a1-a)/b1;
    theta02=atan2(s2,c2);
    theta03=atan2(s3,c3);
    % Theta0
    theta0(i,1)=theta0(i-1,1)+dt;
    theta0(i,2)=theta01*180/pi;
    theta0(i,3)=theta02*180/pi;
    theta0(i,4)=theta03*180/pi;
end