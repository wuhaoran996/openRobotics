% Fillter
% -----------------------
function P = Fillter(K)
dem=0;
% F=zeros(10001,2);
F(1,1)=K(1,1); F(1,2)=K(1,2);
t=length(K(:,1));
for i=2:1:t
    if (K(i,1)~=K(i-1,1))
        F(i-dem,1)=K(i,1); F(i-dem,2)=K(i,2);
    else
        dem=dem+1;
    end
end
P=F;
end
