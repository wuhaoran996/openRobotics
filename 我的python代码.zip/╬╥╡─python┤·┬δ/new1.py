import pygame
import cv2
 
FONT_SIZE = 18  # 字体大小，可自行调整
WIN_SIZE = (1440, 1000)  # 窗口大小，可自行调整
VIDEO_SIZE = (30, 30)  # 视频大小，可自行调整
VIDEO_PATH = 'vedio.mp4'  # 视频文件（可以为常见的视频格式和gif）
STR_TEXT = '!@#'  # 替换字符，可自定义，没有长度限制，但至少得有一个
 
 
def video2imgs(video_name, size):
    img_list = []
    cap = cv2.VideoCapture(video_name)
 
    while cap.isOpened():
        ret, frame = cap.read()
        if ret:
            img = cv2.resize(frame, size, interpolation=cv2.INTER_AREA)
            img_list.append(img)
        else:
            break
    cap.release()
 
    return img_list
 
 
# 初始化pygame
def main():
    pygame.init()
 
    winSur = pygame.display.set_mode(WIN_SIZE)
 
    imgs = video2imgs(VIDEO_PATH, VIDEO_SIZE)
 
    btnFont = pygame.font.SysFont("fangsong", FONT_SIZE)
 
    btnFont.set_bold(True)
 
    # 生成surface
    sur_list = []
    for img in imgs:
        height, width, color = img.shape
        surface = pygame.Surface(WIN_SIZE)
        a = 0
        x, y = 0, 0
        for row in range(height):
            x = 0
            for col in range(width):
                # 获取当前像素RGB
                rgb = img[row][col]
                rgb[0], rgb[2] = rgb[2], rgb[0]
                text_texture = btnFont.render(STR_TEXT[a], True, rgb)
                a = a + 1
                a = a % len(STR_TEXT)
                surface.blit(text_texture, (x, y))
                x = x + FONT_SIZE
            y = y + FONT_SIZE
        sur_list.append(surface)
 
    # 游戏主循环
    current_frame = 0
    while True:
 
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                exit()
 
        pygame.time.delay(int(1000 / 24))
        winSur.fill((0, 0, 0))
        winSur.blit(sur_list[current_frame], [0, 0])
        current_frame += 1
        current_frame %= len(sur_list)
        # 刷新界面
        pygame.display.flip()
 
 
if __name__ == '__main__':
    main()
